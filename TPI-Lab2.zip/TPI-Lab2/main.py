from Controlador.ControladorGeneral import ControladorGeneral

def main():
	controlador = ControladorGeneral()
	controlador.iniciar()
	controlador.mostrarMenu()

if __name__ == "__main__":
	main()