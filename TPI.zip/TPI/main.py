from Controlador.controlador_raza import ControladorRaza
from Controlador.controlador_mascota import ControladorMascota
from Vista.vista_raza import VistaRaza
from Vista.vista_mascota import VistaMascota

def main():
    raza_controller = ControladorRaza()
    mascota_controller = ControladorMascota()

    # Cargar datos desde archivos
    raza_controller.cargarArchivoRazas()
    mascota_controller.cargarArchivoMascotas(raza_controller)  # Pasa raza_controller aquí

    # Mostrar todas las razas
    print("Razas disponibles:")
    VistaRaza.mostrar_todas_las_razas(raza_controller.razas)  # Usa raza_controller.razas

    # Mostrar todas las mascotas
    print("\nMascotas registradas:")
    VistaMascota.mostrar_todas_las_mascotas(mascota_controller.listaMascotas)

    # Crear nuevas Razas y Mascotas
    raza_controller.crearRaza("Pastor Aleman", "Inteligente.")
    raza_nueva = raza_controller.buscarRazaxNombre("Pastor Aleman")
    mascota_controller.crearMascota("Rex", "Perro", raza_nueva, "Enfermo", "Carlos Gomez")

    # Guardar datos actualizados en archivos
    raza_controller.guardarArchivoRazas()
    mascota_controller.guardarArchivoMascotas()

    # Mostrar todas las razas después de agregar
    print("\nRazas disponibles después de agregar:")
    VistaRaza.mostrar_todas_las_razas(raza_controller.razas)

    # Mostrar todas las mascotas después de agregar
    print("\nMascotas registradas después de agregar:")
    VistaMascota.mostrar_todas_las_mascotas(mascota_controller.listaMascotas)

if __name__ == "__main__":
    main()